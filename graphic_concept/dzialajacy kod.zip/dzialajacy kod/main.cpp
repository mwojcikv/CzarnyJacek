
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>

// Enumeration for menu and game states
enum MenuState {
    MAIN_MENU,
    BOTS_MENU,
    MULTIPLAYER_MENU,
    SHOP_MENU,
    EXCLUSIVE_CONTENT_MENU,
    RULES_MENU,
    BLACKJACK_GAME
};

// Card struct to represent a card in the deck
struct Card {
    std::string suit;
    std::string rank;
};

// Function to draw a button
void drawButton(sf::RenderWindow& window, sf::RectangleShape& button, sf::Text& text) {
    window.draw(button);
    window.draw(text);
}

// Function to display a card image in the window
sf::Sprite createCardSprite(const std::string& imagePath) {
    sf::Texture* cardTexture = new sf::Texture();
    if (!cardTexture->loadFromFile(imagePath)) {
        std::cerr << "Failed to load image: " << imagePath << std::endl;
        return sf::Sprite();
    }

    sf::Sprite cardSprite;
    cardSprite.setTexture(*cardTexture);
    cardSprite.setScale(0.3f, 0.3f);  // Further scale down the card to fit more cards
    return cardSprite;
}

// Function to get the path to a card image
std::string getCardImagePath(const Card& card) {
    return "C:/Users/maksi/CLionProjects/untitled14/cards/" + card.rank + "_of_" + card.suit + ".png";
}

// Function to calculate the value of a hand
int calculateHandValue(const std::vector<Card>& hand) {
    int value = 0;
    int aceCount = 0;

    for (const auto& card : hand) {
        if (card.rank == "2") value += 2;
        else if (card.rank == "3") value += 3;
        else if (card.rank == "4") value += 4;
        else if (card.rank == "5") value += 5;
        else if (card.rank == "6") value += 6;
        else if (card.rank == "7") value += 7;
        else if (card.rank == "8") value += 8;
        else if (card.rank == "9") value += 9;
        else if (card.rank == "10" || card.rank == "jack" || card.rank == "queen" || card.rank == "king") value += 10;
        else if (card.rank == "ace") {
            value += 11;
            aceCount++;
        }
    }

    while (value > 21 && aceCount > 0) {
        value -= 10;
        aceCount--;
    }

    return value;
}

// Function to create and shuffle a deck of cards
std::vector<Card> createDeck() {
    std::vector<Card> deck;
    std::vector<std::string> suits = {"hearts", "diamonds", "clubs", "spades"};
    std::vector<std::string> ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"};

    for (const auto& suit : suits) {
        for (const auto& rank : ranks) {
            deck.push_back({suit, rank});
        }
    }

    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(deck.begin(), deck.end(), g);

    return deck;
}

// Function to draw a hand of cards
void drawHand(sf::RenderWindow& window, const std::vector<Card>& hand, float yPosition) {
    float xPosition = 250;
    for (const auto& card : hand) {
        sf::Sprite cardSprite = createCardSprite(getCardImagePath(card));
        cardSprite.setPosition(xPosition, yPosition);
        window.draw(cardSprite);
        xPosition += 40;  // Adjust spacing between cards to fit more cards
    }
}

// Function to create the menu window
void createMenuWindow() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Menu");

    sf::Color backgroundColor = sf::Color::Green;

    sf::Font font;
    if (!font.loadFromFile("C://Users//maksi//Downloads//arial.ttf")) {
        std::cerr << "Failed to load font \"arial.ttf\"" << std::endl;
        return;
    }

    sf::Text title("Czarny Jacek", font, 48);
    title.setFillColor(sf::Color::Black);
    title.setPosition(250, 20);

    sf::RectangleShape buttons[6];
    sf::Text buttonTexts[6];
    std::string buttonLabels[] = {"Rozgrywka z botami", "Rozgrywka multiplayer", "Sklep", "Ekskluzywna zawartosc", "Zasady gry", "Wyjscie"};

    for (int i = 0; i < 6; ++i) {
        buttons[i].setSize(sf::Vector2f(300, 50));
        buttons[i].setFillColor(sf::Color::White);
        buttons[i].setPosition(250, 100 + i * 70);

        buttonTexts[i].setFont(font);
        buttonTexts[i].setString(buttonLabels[i]);
        buttonTexts[i].setCharacterSize(20);
        buttonTexts[i].setFillColor(sf::Color::Black);
        buttonTexts[i].setPosition(270, 110 + i * 70);
    }

    MenuState currentState = MAIN_MENU;

    // Blackjack game variables
    std::vector<Card> deck;
    std::vector<Card> playerHand;
    std::vector<Card> dealerHand;
    bool isPlayerTurn = true;
    bool isGameOver = false;
    std::string gameResult;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                sf::Vector2f mousePosF(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));

                if (currentState == MAIN_MENU) {
                    for (int i = 0; i < 6; ++i) {
                        if (buttons[i].getGlobalBounds().contains(mousePosF)) {
                            switch (i) {
                                case 0:
                                    std::cout << "Rozgrywka z botami selected" << std::endl;
                                    currentState = BLACKJACK_GAME;
                                    deck = createDeck();
                                    playerHand = {deck.back()};
                                    deck.pop_back();
                                    playerHand.push_back(deck.back());
                                    deck.pop_back();
                                    dealerHand = {deck.back()};
                                    deck.pop_back();
                                    dealerHand.push_back(deck.back());
                                    deck.pop_back();
                                    isPlayerTurn = true;
                                    isGameOver = false;
                                    gameResult = "";
                                    break;
                                case 1:
                                    std::cout << "Rozgrywka multiplayer selected" << std::endl;
                                    currentState = MULTIPLAYER_MENU;
                                    break;
                                case 2:
                                    std::cout << "Sklep selected" << std::endl;
                                    currentState = SHOP_MENU;
                                    break;
                                case 3:
                                    std::cout << "Ekskluzywna zawartosc selected" << std::endl;
                                    currentState = EXCLUSIVE_CONTENT_MENU;
                                    break;
                                case 4:
                                    std::cout << "Zasady gry selected" << std::endl;
                                    currentState = RULES_MENU;
                                    break;
                                case 5:
                                    window.close();
                                    break;
                            }
                        }
                    }
                } else if (currentState == BLACKJACK_GAME) {
                    sf::RectangleShape gameButtons[3];
                    sf::Text gameButtonTexts[3];
                    std::string gameButtonLabels[] = {"Hit", "Stand", "Back to Menu"};

                    for (int i = 0; i < 3; ++i) {
                        gameButtons[i].setSize(sf::Vector2f(150, 50));
                        gameButtons[i].setFillColor(sf::Color::White);
                        gameButtons[i].setPosition(50 + i * 170, 500);

                        gameButtonTexts[i].setFont(font);
                        gameButtonTexts[i].setString(gameButtonLabels[i]);
                        gameButtonTexts[i].setCharacterSize(20);
                        gameButtonTexts[i].setFillColor(sf::Color::Black);
                        gameButtonTexts[i].setPosition(70 + i * 170, 510);
                    }

                    for (int i = 0; i < 3; ++i) {
                        if (gameButtons[i].getGlobalBounds().contains(mousePosF) && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                            switch (i) {
                                case 0:  // Hit
                                    if (isPlayerTurn && !isGameOver) {
                                        playerHand.push_back(deck.back());
                                        deck.pop_back();
                                        if (calculateHandValue(playerHand) > 21) {
                                            isGameOver = true;
                                            gameResult = "Player busts! Dealer wins.";
                                        }
                                    }
                                    break;
                                case 1:  // Stand
                                    if (isPlayerTurn && !isGameOver) {
                                        isPlayerTurn = false;
                                        while (calculateHandValue(dealerHand) < 17) {
                                            dealerHand.push_back(deck.back());
                                            deck.pop_back();
                                        }
                                        int playerValue = calculateHandValue(playerHand);
                                        int dealerValue = calculateHandValue(dealerHand);
                                        if (dealerValue > 21 || playerValue > dealerValue) {
                                            gameResult = "Player wins!";
                                        } else if (playerValue < dealerValue) {
                                            gameResult = "Dealer wins!";
                                        } else {
                                            gameResult = "Push!";
                                        }
                                        isGameOver = true;
                                    }
                                    break;
                                case 2:  // Back to menu
                                    currentState = MAIN_MENU;
                                    break;
                            }
                        }
                    }

                    // Draw the game buttons
                    for (int i = 0; i < 3; ++i) {
                        drawButton(window, gameButtons[i], gameButtonTexts[i]);
                    }
                }
            }
        }

        window.clear(backgroundColor);

        if (currentState == MAIN_MENU) {
            window.draw(title);
            for (int i = 0; i < 6; ++i) {
                drawButton(window, buttons[i], buttonTexts[i]);
            }
        } else if (currentState == BLACKJACK_GAME) {
            sf::Text gameTitle("Blackjack", font, 24);
            gameTitle.setFillColor(sf::Color::Black);
            gameTitle.setPosition(250, 20);
            window.draw(gameTitle);

            drawHand(window, playerHand, 350);  // Draw player's hand at the bottom
            drawHand(window, dealerHand, 100);  // Draw dealer's hand at the top

            // Draw the game buttons
            sf::RectangleShape gameButtons[3];
            sf::Text gameButtonTexts[3];
            std::string gameButtonLabels[] = {"Hit", "Stand", "Back to Menu"};

            for (int i = 0; i < 3; ++i) {
                gameButtons[i].setSize(sf::Vector2f(150, 50));
                gameButtons[i].setFillColor(sf::Color::White);
                gameButtons[i].setPosition(50 + i * 170, 500);

                gameButtonTexts[i].setFont(font);
                gameButtonTexts[i].setString(gameButtonLabels[i]);
                gameButtonTexts[i].setCharacterSize(20);
                gameButtonTexts[i].setFillColor(sf::Color::Black);
                gameButtonTexts[i].setPosition(70 + i * 170, 510);
            }

            for (int i = 0; i < 3; ++i) {
                drawButton(window, gameButtons[i], gameButtonTexts[i]);
            }

            if (isGameOver) {
                sf::Text resultText(gameResult, font, 24);
                resultText.setFillColor(sf::Color::Red);
                resultText.setPosition(250, 400);
                window.draw(resultText);
            }
        }

        window.display();
    }
}

int main() {
    createMenuWindow();
    return 0;
}
